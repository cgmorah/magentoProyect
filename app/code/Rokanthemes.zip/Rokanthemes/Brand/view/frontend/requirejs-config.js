/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
var config = {
	map: {
		"*": {
			conflict: "Rokanthemes_Brand/js/conflict",
			owlcarousel: "Rokanthemes_Brand/js/owl.carousel",
			boostrap: "Rokanthemes_Brand/js/bootstrap.min",
		}
	}
};