<?php
/**
 * Copyright © 2015 RokanThemes.com. All rights reserved.

 * @author RokanThemes Team <contact@rokanthemes.com>
 */

namespace Rokanthemes\Blog\Controller\Adminhtml\Post;

/**
 * Blog post change status controller
 */
class MassStatus extends \Rokanthemes\Blog\Controller\Adminhtml\Post
{

}
