<?php
/**
 * Copyright © 2015 RokanThemes.com. All rights reserved.

 * @author RokanThemes Team <contact@rokanthemes.com>
 */
namespace Rokanthemes\Blog\Controller\Adminhtml\Post;

/**
 * Blog post related posts grid controller
 */
class RelatedPostsGrid extends RelatedPosts
{

}
