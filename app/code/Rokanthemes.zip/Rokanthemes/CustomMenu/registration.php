<?php
/**
 * Copyright © 2016 TuanHatay. All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Rokanthemes_CustomMenu',
    __DIR__
);
